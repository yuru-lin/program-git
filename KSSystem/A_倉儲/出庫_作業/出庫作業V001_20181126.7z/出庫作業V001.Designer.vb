﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class 出庫作業V001
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.作業選項T1 = New System.Windows.Forms.ComboBox
        Me.查詢單據T1 = New System.Windows.Forms.Button
        Me.作業T1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.強制出庫 = New System.Windows.Forms.CheckBox
        Me.T1參數1 = New System.Windows.Forms.GroupBox
        Me.T1CB鎖定 = New System.Windows.Forms.CheckBox
        Me.T1TB鎖定庫位 = New System.Windows.Forms.TextBox
        Me.T1DGV4 = New System.Windows.Forms.DataGridView
        Me.顯示項目T1 = New System.Windows.Forms.Button
        Me.單據更換T1 = New System.Windows.Forms.Button
        Me.T1入出 = New System.Windows.Forms.Label
        Me.移除草稿T1 = New System.Windows.Forms.Label
        Me.移除作業T1 = New System.Windows.Forms.Label
        Me.單據移除T1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.條碼明細T1 = New System.Windows.Forms.Button
        Me.列印單號T1 = New System.Windows.Forms.Button
        Me.查看明細T1 = New System.Windows.Forms.Button
        Me.草稿比對T1 = New System.Windows.Forms.Button
        Me.待轉入區T1 = New System.Windows.Forms.Button
        Me.單據條碼T1 = New System.Windows.Forms.Button
        Me.T1DGV3 = New System.Windows.Forms.DataGridView
        Me.T1DGV2 = New System.Windows.Forms.DataGridView
        Me.草稿T1 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.T1DGV1 = New System.Windows.Forms.DataGridView
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.La2申請 = New System.Windows.Forms.Label
        Me.申請作業T2 = New System.Windows.Forms.Button
        Me.參數2 = New System.Windows.Forms.GroupBox
        Me.預設庫位YN = New System.Windows.Forms.CheckBox
        Me.TB預設庫位 = New System.Windows.Forms.TextBox
        Me.轉出檔案T2 = New System.Windows.Forms.Button
        Me.驗收數量T2 = New System.Windows.Forms.Button
        Me.驗收數量L2 = New System.Windows.Forms.Label
        Me.價格T2 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.數量T2 = New System.Windows.Forms.Label
        Me.品項T2 = New System.Windows.Forms.Label
        Me.重覆T2 = New System.Windows.Forms.Label
        Me.已出T2 = New System.Windows.Forms.Label
        Me.未入T2 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.客戶T2 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.客編T2 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.提單T2 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.查看異常T2 = New System.Windows.Forms.Button
        Me.說明T2 = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.備註T2倉 = New System.Windows.Forms.Label
        Me.管理T2 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.附件T2 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.本收T2 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.本空T2 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.前空T2 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.空籃T2 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.司機T3 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.司機T2 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.司機T1 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.運費T2 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.契養T2 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.簽回T2 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.代碼T2 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.日記T2 = New System.Windows.Forms.Label
        Me.備註T2 = New System.Windows.Forms.TextBox
        Me.T2執行時間 = New System.Windows.Forms.Label
        Me.T2DGV3 = New System.Windows.Forms.DataGridView
        Me.草稿T2 = New System.Windows.Forms.Label
        Me.製單T2 = New System.Windows.Forms.Label
        Me.日期T2 = New System.Windows.Forms.Label
        Me.放棄作業T2 = New System.Windows.Forms.Button
        Me.發貨作業T2 = New System.Windows.Forms.Button
        Me.T2DGV1 = New System.Windows.Forms.DataGridView
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.T2DGV2 = New System.Windows.Forms.DataGridView
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.T3 = New System.Windows.Forms.TextBox
        Me.T2 = New System.Windows.Forms.TextBox
        Me.T1 = New System.Windows.Forms.TextBox
        Me.出庫T3 = New System.Windows.Forms.Label
        Me.未入T3 = New System.Windows.Forms.Label
        Me.重覆T3 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.T4作業 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.T4修改品項 = New System.Windows.Forms.GroupBox
        Me.T4ID = New System.Windows.Forms.Label
        Me.T4品名 = New System.Windows.Forms.Label
        Me.T4銷售 = New System.Windows.Forms.Label
        Me.T4存編 = New System.Windows.Forms.Label
        Me.T4條碼 = New System.Windows.Forms.Label
        Me.T4結束作業 = New System.Windows.Forms.Button
        Me.T4贈品修改 = New System.Windows.Forms.Button
        Me.T4銷售修改 = New System.Windows.Forms.Button
        Me.T4變更銷售 = New System.Windows.Forms.Button
        Me.T4回主畫面 = New System.Windows.Forms.Button
        Me.T4重新比對 = New System.Windows.Forms.Button
        Me.T4列出全部 = New System.Windows.Forms.Button
        Me.T4非單品項 = New System.Windows.Forms.Button
        Me.T4列出已出 = New System.Windows.Forms.Button
        Me.T4列出重覆 = New System.Windows.Forms.Button
        Me.T4移除條碼 = New System.Windows.Forms.Button
        Me.T4DGV1 = New System.Windows.Forms.DataGridView
        Me.草稿T4 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.異常條碼T1 = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.PrintDialog = New System.Windows.Forms.PrintDialog
        Me.La差異 = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.T1參數1.SuspendLayout()
        CType(Me.T1DGV4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.T1DGV3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.T1DGV2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.T1DGV1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.參數2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.T2DGV3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.T2DGV1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.T2DGV2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.T4修改品項.SuspendLayout()
        CType(Me.T4DGV1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(124, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "作業類別："
        '
        '作業選項T1
        '
        Me.作業選項T1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.作業選項T1.FormattingEnabled = True
        Me.作業選項T1.Location = New System.Drawing.Point(205, 6)
        Me.作業選項T1.Name = "作業選項T1"
        Me.作業選項T1.Size = New System.Drawing.Size(120, 24)
        Me.作業選項T1.TabIndex = 2
        '
        '查詢單據T1
        '
        Me.查詢單據T1.Location = New System.Drawing.Point(334, 5)
        Me.查詢單據T1.Name = "查詢單據T1"
        Me.查詢單據T1.Size = New System.Drawing.Size(100, 26)
        Me.查詢單據T1.TabIndex = 4
        Me.查詢單據T1.Text = "查詢"
        Me.查詢單據T1.UseVisualStyleBackColor = True
        '
        '作業T1
        '
        Me.作業T1.AutoSize = True
        Me.作業T1.Font = New System.Drawing.Font("新細明體", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.作業T1.ForeColor = System.Drawing.Color.Red
        Me.作業T1.Location = New System.Drawing.Point(619, 6)
        Me.作業T1.Name = "作業T1"
        Me.作業T1.Size = New System.Drawing.Size(159, 35)
        Me.作業T1.TabIndex = 6
        Me.作業T1.Text = "作業類別"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("新細明體", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.Location = New System.Drawing.Point(439, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(195, 35)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "目前作業："
        '
        'TabControl1
        '
        Me.TabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(-5, -5)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1001, 675)
        Me.TabControl1.TabIndex = 7
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.強制出庫)
        Me.TabPage1.Controls.Add(Me.T1參數1)
        Me.TabPage1.Controls.Add(Me.T1DGV4)
        Me.TabPage1.Controls.Add(Me.顯示項目T1)
        Me.TabPage1.Controls.Add(Me.單據更換T1)
        Me.TabPage1.Controls.Add(Me.T1入出)
        Me.TabPage1.Controls.Add(Me.移除草稿T1)
        Me.TabPage1.Controls.Add(Me.移除作業T1)
        Me.TabPage1.Controls.Add(Me.單據移除T1)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.條碼明細T1)
        Me.TabPage1.Controls.Add(Me.列印單號T1)
        Me.TabPage1.Controls.Add(Me.查看明細T1)
        Me.TabPage1.Controls.Add(Me.草稿比對T1)
        Me.TabPage1.Controls.Add(Me.待轉入區T1)
        Me.TabPage1.Controls.Add(Me.單據條碼T1)
        Me.TabPage1.Controls.Add(Me.作業T1)
        Me.TabPage1.Controls.Add(Me.T1DGV3)
        Me.TabPage1.Controls.Add(Me.T1DGV2)
        Me.TabPage1.Controls.Add(Me.草稿T1)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.T1DGV1)
        Me.TabPage1.Controls.Add(Me.作業選項T1)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.查詢單據T1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(993, 645)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "主畫面"
        '
        '強制出庫
        '
        Me.強制出庫.AutoSize = True
        Me.強制出庫.Location = New System.Drawing.Point(109, 320)
        Me.強制出庫.Name = "強制出庫"
        Me.強制出庫.Size = New System.Drawing.Size(91, 20)
        Me.強制出庫.TabIndex = 186
        Me.強制出庫.Text = "強制出庫"
        Me.強制出庫.UseVisualStyleBackColor = True
        Me.強制出庫.Visible = False
        '
        'T1參數1
        '
        Me.T1參數1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.T1參數1.Controls.Add(Me.T1CB鎖定)
        Me.T1參數1.Controls.Add(Me.T1TB鎖定庫位)
        Me.T1參數1.Location = New System.Drawing.Point(732, 316)
        Me.T1參數1.Name = "T1參數1"
        Me.T1參數1.Size = New System.Drawing.Size(183, 58)
        Me.T1參數1.TabIndex = 187
        Me.T1參數1.TabStop = False
        Me.T1參數1.Text = "T1參數1"
        Me.T1參數1.Visible = False
        '
        'T1CB鎖定
        '
        Me.T1CB鎖定.AutoSize = True
        Me.T1CB鎖定.Location = New System.Drawing.Point(6, 26)
        Me.T1CB鎖定.Name = "T1CB鎖定"
        Me.T1CB鎖定.Size = New System.Drawing.Size(91, 20)
        Me.T1CB鎖定.TabIndex = 185
        Me.T1CB鎖定.Text = "鎖定庫位"
        Me.T1CB鎖定.UseVisualStyleBackColor = True
        '
        'T1TB鎖定庫位
        '
        Me.T1TB鎖定庫位.Location = New System.Drawing.Point(98, 23)
        Me.T1TB鎖定庫位.Name = "T1TB鎖定庫位"
        Me.T1TB鎖定庫位.Size = New System.Drawing.Size(80, 27)
        Me.T1TB鎖定庫位.TabIndex = 184
        '
        'T1DGV4
        '
        Me.T1DGV4.AllowUserToAddRows = False
        Me.T1DGV4.AllowUserToDeleteRows = False
        Me.T1DGV4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.T1DGV4.Location = New System.Drawing.Point(331, 380)
        Me.T1DGV4.Name = "T1DGV4"
        Me.T1DGV4.ReadOnly = True
        Me.T1DGV4.RowHeadersVisible = False
        Me.T1DGV4.RowTemplate.Height = 24
        Me.T1DGV4.Size = New System.Drawing.Size(584, 234)
        Me.T1DGV4.TabIndex = 154
        Me.T1DGV4.Visible = False
        '
        '顯示項目T1
        '
        Me.顯示項目T1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.顯示項目T1.Location = New System.Drawing.Point(440, 316)
        Me.顯示項目T1.Name = "顯示項目T1"
        Me.顯示項目T1.Size = New System.Drawing.Size(100, 26)
        Me.顯示項目T1.TabIndex = 153
        Me.顯示項目T1.Text = "明細"
        Me.顯示項目T1.UseVisualStyleBackColor = True
        '
        '單據更換T1
        '
        Me.單據更換T1.ForeColor = System.Drawing.Color.Red
        Me.單據更換T1.Location = New System.Drawing.Point(596, 316)
        Me.單據更換T1.Name = "單據更換T1"
        Me.單據更換T1.Size = New System.Drawing.Size(100, 26)
        Me.單據更換T1.TabIndex = 152
        Me.單據更換T1.Text = "單據更換"
        Me.單據更換T1.UseVisualStyleBackColor = True
        '
        'T1入出
        '
        Me.T1入出.AutoSize = True
        Me.T1入出.Font = New System.Drawing.Font("新細明體", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T1入出.ForeColor = System.Drawing.Color.Red
        Me.T1入出.Location = New System.Drawing.Point(831, 342)
        Me.T1入出.Name = "T1入出"
        Me.T1入出.Size = New System.Drawing.Size(125, 35)
        Me.T1入出.TabIndex = 151
        Me.T1入出.Text = "T1入出"
        '
        '移除草稿T1
        '
        Me.移除草稿T1.AutoSize = True
        Me.移除草稿T1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.移除草稿T1.Location = New System.Drawing.Point(545, 353)
        Me.移除草稿T1.Name = "移除草稿T1"
        Me.移除草稿T1.Size = New System.Drawing.Size(72, 16)
        Me.移除草稿T1.TabIndex = 150
        Me.移除草稿T1.Text = "移除草稿"
        '
        '移除作業T1
        '
        Me.移除作業T1.AutoSize = True
        Me.移除作業T1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.移除作業T1.Location = New System.Drawing.Point(442, 353)
        Me.移除作業T1.Name = "移除作業T1"
        Me.移除作業T1.Size = New System.Drawing.Size(72, 16)
        Me.移除作業T1.TabIndex = 149
        Me.移除作業T1.Text = "移除作業"
        '
        '單據移除T1
        '
        Me.單據移除T1.ForeColor = System.Drawing.Color.Red
        Me.單據移除T1.Location = New System.Drawing.Point(334, 348)
        Me.單據移除T1.Name = "單據移除T1"
        Me.單據移除T1.Size = New System.Drawing.Size(100, 26)
        Me.單據移除T1.TabIndex = 148
        Me.單據移除T1.Text = "單據移除"
        Me.單據移除T1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(815, 316)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 26)
        Me.Button2.TabIndex = 147
        Me.Button2.Text = "單據條碼"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        '條碼明細T1
        '
        Me.條碼明細T1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.條碼明細T1.Location = New System.Drawing.Point(334, 316)
        Me.條碼明細T1.Name = "條碼明細T1"
        Me.條碼明細T1.Size = New System.Drawing.Size(100, 26)
        Me.條碼明細T1.TabIndex = 146
        Me.條碼明細T1.Text = "條碼明細"
        Me.條碼明細T1.UseVisualStyleBackColor = True
        '
        '列印單號T1
        '
        Me.列印單號T1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.列印單號T1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.列印單號T1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.列印單號T1.Location = New System.Drawing.Point(3, 316)
        Me.列印單號T1.Name = "列印單號T1"
        Me.列印單號T1.Size = New System.Drawing.Size(100, 26)
        Me.列印單號T1.TabIndex = 145
        Me.列印單號T1.Text = "列印單號"
        Me.列印單號T1.UseVisualStyleBackColor = False
        '
        '查看明細T1
        '
        Me.查看明細T1.Location = New System.Drawing.Point(334, 31)
        Me.查看明細T1.Name = "查看明細T1"
        Me.查看明細T1.Size = New System.Drawing.Size(100, 26)
        Me.查看明細T1.TabIndex = 144
        Me.查看明細T1.Text = "查看明細"
        Me.查看明細T1.UseVisualStyleBackColor = True
        Me.查看明細T1.Visible = False
        '
        '草稿比對T1
        '
        Me.草稿比對T1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.草稿比對T1.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.草稿比對T1.ForeColor = System.Drawing.Color.Red
        Me.草稿比對T1.Location = New System.Drawing.Point(6, 6)
        Me.草稿比對T1.Name = "草稿比對T1"
        Me.草稿比對T1.Size = New System.Drawing.Size(100, 48)
        Me.草稿比對T1.TabIndex = 27
        Me.草稿比對T1.Text = "草稿比對"
        Me.草稿比對T1.UseVisualStyleBackColor = False
        '
        '待轉入區T1
        '
        Me.待轉入區T1.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.待轉入區T1.Location = New System.Drawing.Point(817, 3)
        Me.待轉入區T1.Name = "待轉入區T1"
        Me.待轉入區T1.Size = New System.Drawing.Size(100, 56)
        Me.待轉入區T1.TabIndex = 143
        Me.待轉入區T1.Text = "待轉" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "入區"
        Me.待轉入區T1.UseVisualStyleBackColor = True
        '
        '單據條碼T1
        '
        Me.單據條碼T1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.單據條碼T1.Location = New System.Drawing.Point(225, 316)
        Me.單據條碼T1.Name = "單據條碼T1"
        Me.單據條碼T1.Size = New System.Drawing.Size(100, 26)
        Me.單據條碼T1.TabIndex = 141
        Me.單據條碼T1.Text = "單據條碼"
        Me.單據條碼T1.UseVisualStyleBackColor = True
        '
        'T1DGV3
        '
        Me.T1DGV3.AllowUserToAddRows = False
        Me.T1DGV3.AllowUserToDeleteRows = False
        Me.T1DGV3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.T1DGV3.Location = New System.Drawing.Point(331, 380)
        Me.T1DGV3.Name = "T1DGV3"
        Me.T1DGV3.ReadOnly = True
        Me.T1DGV3.RowHeadersVisible = False
        Me.T1DGV3.RowTemplate.Height = 24
        Me.T1DGV3.Size = New System.Drawing.Size(584, 234)
        Me.T1DGV3.TabIndex = 28
        '
        'T1DGV2
        '
        Me.T1DGV2.AllowUserToAddRows = False
        Me.T1DGV2.AllowUserToDeleteRows = False
        Me.T1DGV2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.T1DGV2.Location = New System.Drawing.Point(6, 348)
        Me.T1DGV2.Name = "T1DGV2"
        Me.T1DGV2.ReadOnly = True
        Me.T1DGV2.RowTemplate.Height = 24
        Me.T1DGV2.Size = New System.Drawing.Size(319, 266)
        Me.T1DGV2.TabIndex = 24
        '
        '草稿T1
        '
        Me.草稿T1.AutoSize = True
        Me.草稿T1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.草稿T1.Location = New System.Drawing.Point(202, 36)
        Me.草稿T1.Name = "草稿T1"
        Me.草稿T1.Size = New System.Drawing.Size(72, 16)
        Me.草稿T1.TabIndex = 23
        Me.草稿T1.Text = "作業草稿"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label13.Location = New System.Drawing.Point(124, 36)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(88, 16)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "草稿號編："
        '
        'T1DGV1
        '
        Me.T1DGV1.AllowUserToAddRows = False
        Me.T1DGV1.AllowUserToDeleteRows = False
        Me.T1DGV1.AllowUserToResizeRows = False
        Me.T1DGV1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.T1DGV1.Location = New System.Drawing.Point(5, 60)
        Me.T1DGV1.Name = "T1DGV1"
        Me.T1DGV1.ReadOnly = True
        Me.T1DGV1.RowHeadersVisible = False
        Me.T1DGV1.RowTemplate.Height = 24
        Me.T1DGV1.Size = New System.Drawing.Size(910, 250)
        Me.T1DGV1.TabIndex = 8
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.La差異)
        Me.TabPage2.Controls.Add(Me.La2申請)
        Me.TabPage2.Controls.Add(Me.申請作業T2)
        Me.TabPage2.Controls.Add(Me.參數2)
        Me.TabPage2.Controls.Add(Me.轉出檔案T2)
        Me.TabPage2.Controls.Add(Me.驗收數量T2)
        Me.TabPage2.Controls.Add(Me.驗收數量L2)
        Me.TabPage2.Controls.Add(Me.價格T2)
        Me.TabPage2.Controls.Add(Me.Label32)
        Me.TabPage2.Controls.Add(Me.數量T2)
        Me.TabPage2.Controls.Add(Me.品項T2)
        Me.TabPage2.Controls.Add(Me.重覆T2)
        Me.TabPage2.Controls.Add(Me.已出T2)
        Me.TabPage2.Controls.Add(Me.未入T2)
        Me.TabPage2.Controls.Add(Me.Label39)
        Me.TabPage2.Controls.Add(Me.Label37)
        Me.TabPage2.Controls.Add(Me.Label35)
        Me.TabPage2.Controls.Add(Me.Label33)
        Me.TabPage2.Controls.Add(Me.Label31)
        Me.TabPage2.Controls.Add(Me.客戶T2)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Controls.Add(Me.客編T2)
        Me.TabPage2.Controls.Add(Me.Label17)
        Me.TabPage2.Controls.Add(Me.提單T2)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.查看異常T2)
        Me.TabPage2.Controls.Add(Me.說明T2)
        Me.TabPage2.Controls.Add(Me.GroupBox1)
        Me.TabPage2.Controls.Add(Me.備註T2)
        Me.TabPage2.Controls.Add(Me.T2執行時間)
        Me.TabPage2.Controls.Add(Me.T2DGV3)
        Me.TabPage2.Controls.Add(Me.草稿T2)
        Me.TabPage2.Controls.Add(Me.製單T2)
        Me.TabPage2.Controls.Add(Me.日期T2)
        Me.TabPage2.Controls.Add(Me.放棄作業T2)
        Me.TabPage2.Controls.Add(Me.發貨作業T2)
        Me.TabPage2.Controls.Add(Me.T2DGV1)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.T2DGV2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(993, 645)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "比對"
        '
        'La2申請
        '
        Me.La2申請.AutoSize = True
        Me.La2申請.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.La2申請.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.La2申請.Location = New System.Drawing.Point(641, 592)
        Me.La2申請.Name = "La2申請"
        Me.La2申請.Size = New System.Drawing.Size(12, 16)
        Me.La2申請.TabIndex = 184
        Me.La2申請.Text = "."
        '
        '申請作業T2
        '
        Me.申請作業T2.Font = New System.Drawing.Font("新細明體", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.申請作業T2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.申請作業T2.Location = New System.Drawing.Point(640, 546)
        Me.申請作業T2.Name = "申請作業T2"
        Me.申請作業T2.Size = New System.Drawing.Size(100, 65)
        Me.申請作業T2.TabIndex = 187
        Me.申請作業T2.Text = "申請"
        Me.申請作業T2.UseVisualStyleBackColor = True
        Me.申請作業T2.Visible = False
        '
        '參數2
        '
        Me.參數2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.參數2.Controls.Add(Me.預設庫位YN)
        Me.參數2.Controls.Add(Me.TB預設庫位)
        Me.參數2.Location = New System.Drawing.Point(734, 217)
        Me.參數2.Name = "參數2"
        Me.參數2.Size = New System.Drawing.Size(183, 58)
        Me.參數2.TabIndex = 186
        Me.參數2.TabStop = False
        Me.參數2.Text = "參數2"
        Me.參數2.Visible = False
        '
        '預設庫位YN
        '
        Me.預設庫位YN.AutoSize = True
        Me.預設庫位YN.Location = New System.Drawing.Point(6, 26)
        Me.預設庫位YN.Name = "預設庫位YN"
        Me.預設庫位YN.Size = New System.Drawing.Size(91, 20)
        Me.預設庫位YN.TabIndex = 185
        Me.預設庫位YN.Text = "預設庫位"
        Me.預設庫位YN.UseVisualStyleBackColor = True
        '
        'TB預設庫位
        '
        Me.TB預設庫位.Location = New System.Drawing.Point(98, 23)
        Me.TB預設庫位.Name = "TB預設庫位"
        Me.TB預設庫位.Size = New System.Drawing.Size(80, 27)
        Me.TB預設庫位.TabIndex = 184
        Me.TB預設庫位.Text = "K10-1"
        '
        '轉出檔案T2
        '
        Me.轉出檔案T2.Location = New System.Drawing.Point(731, 28)
        Me.轉出檔案T2.Name = "轉出檔案T2"
        Me.轉出檔案T2.Size = New System.Drawing.Size(100, 26)
        Me.轉出檔案T2.TabIndex = 143
        Me.轉出檔案T2.Text = "轉出檔案"
        Me.轉出檔案T2.UseVisualStyleBackColor = True
        '
        '驗收數量T2
        '
        Me.驗收數量T2.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.驗收數量T2.ForeColor = System.Drawing.Color.Red
        Me.驗收數量T2.Location = New System.Drawing.Point(837, 281)
        Me.驗收數量T2.Name = "驗收數量T2"
        Me.驗收數量T2.Size = New System.Drawing.Size(80, 47)
        Me.驗收數量T2.TabIndex = 182
        Me.驗收數量T2.Text = "驗收" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "數量"
        Me.驗收數量T2.UseVisualStyleBackColor = True
        Me.驗收數量T2.Visible = False
        '
        '驗收數量L2
        '
        Me.驗收數量L2.AutoSize = True
        Me.驗收數量L2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.驗收數量L2.ForeColor = System.Drawing.Color.Red
        Me.驗收數量L2.Location = New System.Drawing.Point(790, 246)
        Me.驗收數量L2.Name = "驗收數量L2"
        Me.驗收數量L2.Size = New System.Drawing.Size(127, 32)
        Me.驗收數量L2.TabIndex = 183
        Me.驗收數量L2.Text = "無條碼管理：" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "請輸入驗收數量"
        Me.驗收數量L2.Visible = False
        '
        '價格T2
        '
        Me.價格T2.AutoSize = True
        Me.價格T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.價格T2.Location = New System.Drawing.Point(688, 214)
        Me.價格T2.Name = "價格T2"
        Me.價格T2.Size = New System.Drawing.Size(40, 16)
        Me.價格T2.TabIndex = 181
        Me.價格T2.Text = "價格"
        Me.價格T2.Visible = False
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label32.Location = New System.Drawing.Point(640, 214)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(56, 16)
        Me.Label32.TabIndex = 180
        Me.Label32.Text = "價格："
        Me.Label32.Visible = False
        '
        '數量T2
        '
        Me.數量T2.AutoSize = True
        Me.數量T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.數量T2.Location = New System.Drawing.Point(688, 294)
        Me.數量T2.Name = "數量T2"
        Me.數量T2.Size = New System.Drawing.Size(40, 16)
        Me.數量T2.TabIndex = 179
        Me.數量T2.Text = "數量"
        '
        '品項T2
        '
        Me.品項T2.AutoSize = True
        Me.品項T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.品項T2.Location = New System.Drawing.Point(688, 278)
        Me.品項T2.Name = "品項T2"
        Me.品項T2.Size = New System.Drawing.Size(40, 16)
        Me.品項T2.TabIndex = 177
        Me.品項T2.Text = "品項"
        '
        '重覆T2
        '
        Me.重覆T2.AutoSize = True
        Me.重覆T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.重覆T2.Location = New System.Drawing.Point(688, 262)
        Me.重覆T2.Name = "重覆T2"
        Me.重覆T2.Size = New System.Drawing.Size(40, 16)
        Me.重覆T2.TabIndex = 175
        Me.重覆T2.Text = "重覆"
        '
        '已出T2
        '
        Me.已出T2.AutoSize = True
        Me.已出T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.已出T2.Location = New System.Drawing.Point(688, 246)
        Me.已出T2.Name = "已出T2"
        Me.已出T2.Size = New System.Drawing.Size(40, 16)
        Me.已出T2.TabIndex = 173
        Me.已出T2.Text = "已出"
        '
        '未入T2
        '
        Me.未入T2.AutoSize = True
        Me.未入T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.未入T2.Location = New System.Drawing.Point(688, 230)
        Me.未入T2.Name = "未入T2"
        Me.未入T2.Size = New System.Drawing.Size(40, 16)
        Me.未入T2.TabIndex = 171
        Me.未入T2.Text = "未入"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label39.Location = New System.Drawing.Point(640, 294)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(56, 16)
        Me.Label39.TabIndex = 178
        Me.Label39.Text = "數量："
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label37.Location = New System.Drawing.Point(640, 278)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(56, 16)
        Me.Label37.TabIndex = 176
        Me.Label37.Text = "品項："
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label35.Location = New System.Drawing.Point(640, 262)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(56, 16)
        Me.Label35.TabIndex = 174
        Me.Label35.Text = "重覆："
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label33.Location = New System.Drawing.Point(640, 246)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(56, 16)
        Me.Label33.TabIndex = 172
        Me.Label33.Text = "已出："
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label31.Location = New System.Drawing.Point(640, 230)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(56, 16)
        Me.Label31.TabIndex = 170
        Me.Label31.Text = "未入："
        '
        '客戶T2
        '
        Me.客戶T2.AutoSize = True
        Me.客戶T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.客戶T2.Location = New System.Drawing.Point(468, 36)
        Me.客戶T2.Name = "客戶T2"
        Me.客戶T2.Size = New System.Drawing.Size(40, 16)
        Me.客戶T2.TabIndex = 169
        Me.客戶T2.Text = "客戶"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label19.Location = New System.Drawing.Point(390, 36)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(88, 16)
        Me.Label19.TabIndex = 168
        Me.Label19.Text = "客戶名稱："
        '
        '客編T2
        '
        Me.客編T2.AutoSize = True
        Me.客編T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.客編T2.Location = New System.Drawing.Point(278, 36)
        Me.客編T2.Name = "客編T2"
        Me.客編T2.Size = New System.Drawing.Size(40, 16)
        Me.客編T2.TabIndex = 167
        Me.客編T2.Text = "客編"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label17.Location = New System.Drawing.Point(200, 36)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(88, 16)
        Me.Label17.TabIndex = 166
        Me.Label17.Text = "客戶存編："
        '
        '提單T2
        '
        Me.提單T2.AutoSize = True
        Me.提單T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.提單T2.Location = New System.Drawing.Point(81, 36)
        Me.提單T2.Name = "提單T2"
        Me.提單T2.Size = New System.Drawing.Size(40, 16)
        Me.提單T2.TabIndex = 165
        Me.提單T2.Text = "提單"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label12.Location = New System.Drawing.Point(3, 36)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(88, 16)
        Me.Label12.TabIndex = 164
        Me.Label12.Text = "提貨單號："
        '
        '查看異常T2
        '
        Me.查看異常T2.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.查看異常T2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.查看異常T2.Location = New System.Drawing.Point(837, 7)
        Me.查看異常T2.Name = "查看異常T2"
        Me.查看異常T2.Size = New System.Drawing.Size(80, 47)
        Me.查看異常T2.TabIndex = 163
        Me.查看異常T2.Text = "查看" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "異常"
        Me.查看異常T2.UseVisualStyleBackColor = True
        '
        '說明T2
        '
        Me.說明T2.BackColor = System.Drawing.Color.White
        Me.說明T2.Location = New System.Drawing.Point(640, 434)
        Me.說明T2.Multiline = True
        Me.說明T2.Name = "說明T2"
        Me.說明T2.Size = New System.Drawing.Size(277, 101)
        Me.說明T2.TabIndex = 162
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.備註T2倉)
        Me.GroupBox1.Controls.Add(Me.管理T2)
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.Label34)
        Me.GroupBox1.Controls.Add(Me.附件T2)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.本收T2)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.本空T2)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.前空T2)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.空籃T2)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.司機T3)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.司機T2)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.司機T1)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.運費T2)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.契養T2)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.簽回T2)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.代碼T2)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.日記T2)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 336)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(344, 254)
        Me.GroupBox1.TabIndex = 161
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "參數"
        Me.GroupBox1.Visible = False
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label36.Location = New System.Drawing.Point(172, 23)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(88, 16)
        Me.Label36.TabIndex = 184
        Me.Label36.Text = "倉儲備註："
        '
        '備註T2倉
        '
        Me.備註T2倉.AutoSize = True
        Me.備註T2倉.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.備註T2倉.Location = New System.Drawing.Point(257, 23)
        Me.備註T2倉.Name = "備註T2倉"
        Me.備註T2倉.Size = New System.Drawing.Size(72, 16)
        Me.備註T2倉.TabIndex = 185
        Me.備註T2倉.Text = "倉儲備註"
        '
        '管理T2
        '
        Me.管理T2.AutoSize = True
        Me.管理T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.管理T2.Location = New System.Drawing.Point(281, 215)
        Me.管理T2.Name = "管理T2"
        Me.管理T2.Size = New System.Drawing.Size(40, 16)
        Me.管理T2.TabIndex = 183
        Me.管理T2.Text = "管理"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label24.Location = New System.Drawing.Point(6, 215)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(72, 16)
        Me.Label24.TabIndex = 175
        Me.Label24.Text = "附件內容"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label34.Location = New System.Drawing.Point(233, 215)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(56, 16)
        Me.Label34.TabIndex = 182
        Me.Label34.Text = "管理："
        '
        '附件T2
        '
        Me.附件T2.AutoSize = True
        Me.附件T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.附件T2.Location = New System.Drawing.Point(91, 215)
        Me.附件T2.Name = "附件T2"
        Me.附件T2.Size = New System.Drawing.Size(40, 16)
        Me.附件T2.TabIndex = 176
        Me.附件T2.Text = "附件"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label30.Location = New System.Drawing.Point(6, 199)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(88, 16)
        Me.Label30.TabIndex = 173
        Me.Label30.Text = "本期收回："
        '
        '本收T2
        '
        Me.本收T2.AutoSize = True
        Me.本收T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.本收T2.Location = New System.Drawing.Point(91, 199)
        Me.本收T2.Name = "本收T2"
        Me.本收T2.Size = New System.Drawing.Size(40, 16)
        Me.本收T2.TabIndex = 174
        Me.本收T2.Text = "本收"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label28.Location = New System.Drawing.Point(6, 183)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(88, 16)
        Me.Label28.TabIndex = 171
        Me.Label28.Text = "本期空籃："
        '
        '本空T2
        '
        Me.本空T2.AutoSize = True
        Me.本空T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.本空T2.Location = New System.Drawing.Point(91, 183)
        Me.本空T2.Name = "本空T2"
        Me.本空T2.Size = New System.Drawing.Size(40, 16)
        Me.本空T2.TabIndex = 172
        Me.本空T2.Text = "本空"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label26.Location = New System.Drawing.Point(6, 167)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(88, 16)
        Me.Label26.TabIndex = 169
        Me.Label26.Text = "前期空籃："
        '
        '前空T2
        '
        Me.前空T2.AutoSize = True
        Me.前空T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.前空T2.Location = New System.Drawing.Point(91, 167)
        Me.前空T2.Name = "前空T2"
        Me.前空T2.Size = New System.Drawing.Size(40, 16)
        Me.前空T2.TabIndex = 170
        Me.前空T2.Text = "前空"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label22.Location = New System.Drawing.Point(6, 151)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(88, 16)
        Me.Label22.TabIndex = 167
        Me.Label22.Text = "更新空籃："
        '
        '空籃T2
        '
        Me.空籃T2.AutoSize = True
        Me.空籃T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.空籃T2.Location = New System.Drawing.Point(91, 151)
        Me.空籃T2.Name = "空籃T2"
        Me.空籃T2.Size = New System.Drawing.Size(40, 16)
        Me.空籃T2.TabIndex = 168
        Me.空籃T2.Text = "空籃"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label20.Location = New System.Drawing.Point(6, 135)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(88, 16)
        Me.Label20.TabIndex = 165
        Me.Label20.Text = "司機第三："
        '
        '司機T3
        '
        Me.司機T3.AutoSize = True
        Me.司機T3.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.司機T3.Location = New System.Drawing.Point(91, 135)
        Me.司機T3.Name = "司機T3"
        Me.司機T3.Size = New System.Drawing.Size(40, 16)
        Me.司機T3.TabIndex = 166
        Me.司機T3.Text = "司機"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label25.Location = New System.Drawing.Point(6, 119)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(88, 16)
        Me.Label25.TabIndex = 163
        Me.Label25.Text = "司機第二："
        '
        '司機T2
        '
        Me.司機T2.AutoSize = True
        Me.司機T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.司機T2.Location = New System.Drawing.Point(91, 119)
        Me.司機T2.Name = "司機T2"
        Me.司機T2.Size = New System.Drawing.Size(40, 16)
        Me.司機T2.TabIndex = 164
        Me.司機T2.Text = "司機"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label23.Location = New System.Drawing.Point(6, 103)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(88, 16)
        Me.Label23.TabIndex = 161
        Me.Label23.Text = "司機第一："
        '
        '司機T1
        '
        Me.司機T1.AutoSize = True
        Me.司機T1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.司機T1.Location = New System.Drawing.Point(91, 103)
        Me.司機T1.Name = "司機T1"
        Me.司機T1.Size = New System.Drawing.Size(40, 16)
        Me.司機T1.TabIndex = 162
        Me.司機T1.Text = "司機"
        Me.司機T1.Visible = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label21.Location = New System.Drawing.Point(6, 87)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(88, 16)
        Me.Label21.TabIndex = 159
        Me.Label21.Text = "運費金額："
        '
        '運費T2
        '
        Me.運費T2.AutoSize = True
        Me.運費T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.運費T2.Location = New System.Drawing.Point(91, 87)
        Me.運費T2.Name = "運費T2"
        Me.運費T2.Size = New System.Drawing.Size(40, 16)
        Me.運費T2.TabIndex = 160
        Me.運費T2.Text = "運費"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label18.Location = New System.Drawing.Point(6, 71)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(88, 16)
        Me.Label18.TabIndex = 157
        Me.Label18.Text = "契養批號："
        '
        '契養T2
        '
        Me.契養T2.AutoSize = True
        Me.契養T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.契養T2.Location = New System.Drawing.Point(91, 71)
        Me.契養T2.Name = "契養T2"
        Me.契養T2.Size = New System.Drawing.Size(40, 16)
        Me.契養T2.TabIndex = 158
        Me.契養T2.Text = "契養"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 55)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(88, 16)
        Me.Label7.TabIndex = 155
        Me.Label7.Text = "出貨簽回："
        '
        '簽回T2
        '
        Me.簽回T2.AutoSize = True
        Me.簽回T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.簽回T2.Location = New System.Drawing.Point(91, 55)
        Me.簽回T2.Name = "簽回T2"
        Me.簽回T2.Size = New System.Drawing.Size(40, 16)
        Me.簽回T2.TabIndex = 156
        Me.簽回T2.Text = "簽回"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label10.Location = New System.Drawing.Point(6, 23)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(88, 16)
        Me.Label10.TabIndex = 153
        Me.Label10.Text = "發貨代碼："
        '
        '代碼T2
        '
        Me.代碼T2.AutoSize = True
        Me.代碼T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.代碼T2.Location = New System.Drawing.Point(91, 23)
        Me.代碼T2.Name = "代碼T2"
        Me.代碼T2.Size = New System.Drawing.Size(40, 16)
        Me.代碼T2.TabIndex = 154
        Me.代碼T2.Text = "代碼"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label8.Location = New System.Drawing.Point(6, 39)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 16)
        Me.Label8.TabIndex = 151
        Me.Label8.Text = "日記帳別："
        '
        '日記T2
        '
        Me.日記T2.AutoSize = True
        Me.日記T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.日記T2.Location = New System.Drawing.Point(91, 39)
        Me.日記T2.Name = "日記T2"
        Me.日記T2.Size = New System.Drawing.Size(40, 16)
        Me.日記T2.TabIndex = 152
        Me.日記T2.Text = "日記"
        '
        '備註T2
        '
        Me.備註T2.BackColor = System.Drawing.Color.White
        Me.備註T2.Location = New System.Drawing.Point(640, 336)
        Me.備註T2.Multiline = True
        Me.備註T2.Name = "備註T2"
        Me.備註T2.ReadOnly = True
        Me.備註T2.Size = New System.Drawing.Size(277, 92)
        Me.備註T2.TabIndex = 160
        '
        'T2執行時間
        '
        Me.T2執行時間.AutoSize = True
        Me.T2執行時間.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T2執行時間.Location = New System.Drawing.Point(657, 10)
        Me.T2執行時間.Name = "T2執行時間"
        Me.T2執行時間.Size = New System.Drawing.Size(72, 16)
        Me.T2執行時間.TabIndex = 158
        Me.T2執行時間.Text = "執行時間"
        '
        'T2DGV3
        '
        Me.T2DGV3.AllowUserToAddRows = False
        Me.T2DGV3.AllowUserToDeleteRows = False
        Me.T2DGV3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.T2DGV3.Location = New System.Drawing.Point(640, 60)
        Me.T2DGV3.Name = "T2DGV3"
        Me.T2DGV3.ReadOnly = True
        Me.T2DGV3.RowTemplate.Height = 24
        Me.T2DGV3.Size = New System.Drawing.Size(277, 151)
        Me.T2DGV3.TabIndex = 157
        '
        '草稿T2
        '
        Me.草稿T2.AutoSize = True
        Me.草稿T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.草稿T2.Location = New System.Drawing.Point(81, 10)
        Me.草稿T2.Name = "草稿T2"
        Me.草稿T2.Size = New System.Drawing.Size(40, 16)
        Me.草稿T2.TabIndex = 144
        Me.草稿T2.Text = "草稿"
        '
        '製單T2
        '
        Me.製單T2.AutoSize = True
        Me.製單T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.製單T2.Location = New System.Drawing.Point(468, 10)
        Me.製單T2.Name = "製單T2"
        Me.製單T2.Size = New System.Drawing.Size(40, 16)
        Me.製單T2.TabIndex = 148
        Me.製單T2.Text = "製單"
        '
        '日期T2
        '
        Me.日期T2.AutoSize = True
        Me.日期T2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.日期T2.Location = New System.Drawing.Point(278, 10)
        Me.日期T2.Name = "日期T2"
        Me.日期T2.Size = New System.Drawing.Size(40, 16)
        Me.日期T2.TabIndex = 146
        Me.日期T2.Text = "日期"
        '
        '放棄作業T2
        '
        Me.放棄作業T2.Font = New System.Drawing.Font("新細明體", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.放棄作業T2.ForeColor = System.Drawing.Color.Blue
        Me.放棄作業T2.Location = New System.Drawing.Point(710, 546)
        Me.放棄作業T2.Name = "放棄作業T2"
        Me.放棄作業T2.Size = New System.Drawing.Size(100, 65)
        Me.放棄作業T2.TabIndex = 155
        Me.放棄作業T2.Text = "放棄"
        Me.放棄作業T2.UseVisualStyleBackColor = True
        '
        '發貨作業T2
        '
        Me.發貨作業T2.Font = New System.Drawing.Font("新細明體", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.發貨作業T2.ForeColor = System.Drawing.Color.Red
        Me.發貨作業T2.Location = New System.Drawing.Point(817, 546)
        Me.發貨作業T2.Name = "發貨作業T2"
        Me.發貨作業T2.Size = New System.Drawing.Size(100, 65)
        Me.發貨作業T2.TabIndex = 141
        Me.發貨作業T2.Text = "發貨"
        Me.發貨作業T2.UseVisualStyleBackColor = True
        '
        'T2DGV1
        '
        Me.T2DGV1.AllowUserToAddRows = False
        Me.T2DGV1.AllowUserToDeleteRows = False
        Me.T2DGV1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.T2DGV1.Location = New System.Drawing.Point(5, 60)
        Me.T2DGV1.Name = "T2DGV1"
        Me.T2DGV1.ReadOnly = True
        Me.T2DGV1.RowTemplate.Height = 24
        Me.T2DGV1.Size = New System.Drawing.Size(629, 250)
        Me.T2DGV1.TabIndex = 142
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label11.Location = New System.Drawing.Point(640, 316)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(88, 16)
        Me.Label11.TabIndex = 149
        Me.Label11.Text = "備註說明："
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label9.Location = New System.Drawing.Point(390, 10)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(88, 16)
        Me.Label9.TabIndex = 147
        Me.Label9.Text = "發貨製單："
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.Location = New System.Drawing.Point(200, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 16)
        Me.Label3.TabIndex = 145
        Me.Label3.Text = "草稿日期："
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label6.Location = New System.Drawing.Point(3, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 16)
        Me.Label6.TabIndex = 143
        Me.Label6.Text = "作業草稿："
        '
        'T2DGV2
        '
        Me.T2DGV2.AllowUserToAddRows = False
        Me.T2DGV2.AllowUserToDeleteRows = False
        Me.T2DGV2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.T2DGV2.Location = New System.Drawing.Point(3, 316)
        Me.T2DGV2.Name = "T2DGV2"
        Me.T2DGV2.ReadOnly = True
        Me.T2DGV2.RowTemplate.Height = 24
        Me.T2DGV2.Size = New System.Drawing.Size(631, 295)
        Me.T2DGV2.TabIndex = 156
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.SystemColors.Control
        Me.TabPage3.Controls.Add(Me.T3)
        Me.TabPage3.Controls.Add(Me.T2)
        Me.TabPage3.Controls.Add(Me.T1)
        Me.TabPage3.Controls.Add(Me.出庫T3)
        Me.TabPage3.Controls.Add(Me.未入T3)
        Me.TabPage3.Controls.Add(Me.重覆T3)
        Me.TabPage3.Controls.Add(Me.Label16)
        Me.TabPage3.Controls.Add(Me.Label15)
        Me.TabPage3.Controls.Add(Me.Label14)
        Me.TabPage3.Location = New System.Drawing.Point(4, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(993, 645)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "參數"
        '
        'T3
        '
        Me.T3.Location = New System.Drawing.Point(188, 115)
        Me.T3.Name = "T3"
        Me.T3.Size = New System.Drawing.Size(80, 27)
        Me.T3.TabIndex = 187
        Me.T3.Text = "80"
        '
        'T2
        '
        Me.T2.Location = New System.Drawing.Point(102, 115)
        Me.T2.Name = "T2"
        Me.T2.Size = New System.Drawing.Size(80, 27)
        Me.T2.TabIndex = 186
        Me.T2.Text = "150"
        '
        'T1
        '
        Me.T1.Location = New System.Drawing.Point(16, 115)
        Me.T1.Name = "T1"
        Me.T1.Size = New System.Drawing.Size(80, 27)
        Me.T1.TabIndex = 185
        Me.T1.Text = "25"
        '
        '出庫T3
        '
        Me.出庫T3.AutoSize = True
        Me.出庫T3.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.出庫T3.Location = New System.Drawing.Point(75, 42)
        Me.出庫T3.Name = "出庫T3"
        Me.出庫T3.Size = New System.Drawing.Size(40, 16)
        Me.出庫T3.TabIndex = 32
        Me.出庫T3.Text = "出庫"
        '
        '未入T3
        '
        Me.未入T3.AutoSize = True
        Me.未入T3.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.未入T3.Location = New System.Drawing.Point(75, 26)
        Me.未入T3.Name = "未入T3"
        Me.未入T3.Size = New System.Drawing.Size(40, 16)
        Me.未入T3.TabIndex = 31
        Me.未入T3.Text = "未入"
        '
        '重覆T3
        '
        Me.重覆T3.AutoSize = True
        Me.重覆T3.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.重覆T3.Location = New System.Drawing.Point(75, 10)
        Me.重覆T3.Name = "重覆T3"
        Me.重覆T3.Size = New System.Drawing.Size(40, 16)
        Me.重覆T3.TabIndex = 30
        Me.重覆T3.Text = "重覆"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label16.Location = New System.Drawing.Point(13, 42)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(72, 16)
        Me.Label16.TabIndex = 35
        Me.Label16.Text = "出　庫："
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label15.Location = New System.Drawing.Point(13, 26)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(72, 16)
        Me.Label15.TabIndex = 34
        Me.Label15.Text = "未入庫："
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label14.Location = New System.Drawing.Point(13, 10)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 16)
        Me.Label14.TabIndex = 33
        Me.Label14.Text = "重　覆："
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.T4作業)
        Me.TabPage4.Controls.Add(Me.Label27)
        Me.TabPage4.Controls.Add(Me.T4修改品項)
        Me.TabPage4.Controls.Add(Me.T4結束作業)
        Me.TabPage4.Controls.Add(Me.T4贈品修改)
        Me.TabPage4.Controls.Add(Me.T4銷售修改)
        Me.TabPage4.Controls.Add(Me.T4變更銷售)
        Me.TabPage4.Controls.Add(Me.T4回主畫面)
        Me.TabPage4.Controls.Add(Me.T4重新比對)
        Me.TabPage4.Controls.Add(Me.T4列出全部)
        Me.TabPage4.Controls.Add(Me.T4非單品項)
        Me.TabPage4.Controls.Add(Me.T4列出已出)
        Me.TabPage4.Controls.Add(Me.T4列出重覆)
        Me.TabPage4.Controls.Add(Me.T4移除條碼)
        Me.TabPage4.Controls.Add(Me.T4DGV1)
        Me.TabPage4.Controls.Add(Me.草稿T4)
        Me.TabPage4.Controls.Add(Me.Label29)
        Me.TabPage4.Location = New System.Drawing.Point(4, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(993, 645)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "異常"
        '
        'T4作業
        '
        Me.T4作業.AutoSize = True
        Me.T4作業.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4作業.Location = New System.Drawing.Point(81, 36)
        Me.T4作業.Name = "T4作業"
        Me.T4作業.Size = New System.Drawing.Size(40, 16)
        Me.T4作業.TabIndex = 194
        Me.T4作業.Text = "作業"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label27.Location = New System.Drawing.Point(3, 36)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(88, 16)
        Me.Label27.TabIndex = 193
        Me.Label27.Text = "目前作業："
        '
        'T4修改品項
        '
        Me.T4修改品項.Controls.Add(Me.T4ID)
        Me.T4修改品項.Controls.Add(Me.T4品名)
        Me.T4修改品項.Controls.Add(Me.T4銷售)
        Me.T4修改品項.Controls.Add(Me.T4存編)
        Me.T4修改品項.Controls.Add(Me.T4條碼)
        Me.T4修改品項.Location = New System.Drawing.Point(258, 525)
        Me.T4修改品項.Name = "T4修改品項"
        Me.T4修改品項.Size = New System.Drawing.Size(533, 79)
        Me.T4修改品項.TabIndex = 192
        Me.T4修改品項.TabStop = False
        Me.T4修改品項.Text = "修改品項"
        Me.T4修改品項.Visible = False
        '
        'T4ID
        '
        Me.T4ID.AutoSize = True
        Me.T4ID.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4ID.Location = New System.Drawing.Point(410, 23)
        Me.T4ID.Name = "T4ID"
        Me.T4ID.Size = New System.Drawing.Size(24, 16)
        Me.T4ID.TabIndex = 197
        Me.T4ID.Text = "ID"
        '
        'T4品名
        '
        Me.T4品名.AutoSize = True
        Me.T4品名.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4品名.Location = New System.Drawing.Point(6, 55)
        Me.T4品名.Name = "T4品名"
        Me.T4品名.Size = New System.Drawing.Size(40, 16)
        Me.T4品名.TabIndex = 196
        Me.T4品名.Text = "品名"
        '
        'T4銷售
        '
        Me.T4銷售.AutoSize = True
        Me.T4銷售.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4銷售.Location = New System.Drawing.Point(225, 23)
        Me.T4銷售.Name = "T4銷售"
        Me.T4銷售.Size = New System.Drawing.Size(40, 16)
        Me.T4銷售.TabIndex = 195
        Me.T4銷售.Text = "銷售"
        '
        'T4存編
        '
        Me.T4存編.AutoSize = True
        Me.T4存編.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4存編.Location = New System.Drawing.Point(6, 39)
        Me.T4存編.Name = "T4存編"
        Me.T4存編.Size = New System.Drawing.Size(40, 16)
        Me.T4存編.TabIndex = 194
        Me.T4存編.Text = "存編"
        '
        'T4條碼
        '
        Me.T4條碼.AutoSize = True
        Me.T4條碼.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4條碼.Location = New System.Drawing.Point(6, 23)
        Me.T4條碼.Name = "T4條碼"
        Me.T4條碼.Size = New System.Drawing.Size(40, 16)
        Me.T4條碼.TabIndex = 193
        Me.T4條碼.Text = "條碼"
        '
        'T4結束作業
        '
        Me.T4結束作業.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4結束作業.ForeColor = System.Drawing.Color.Blue
        Me.T4結束作業.Location = New System.Drawing.Point(797, 532)
        Me.T4結束作業.Name = "T4結束作業"
        Me.T4結束作業.Size = New System.Drawing.Size(120, 47)
        Me.T4結束作業.TabIndex = 191
        Me.T4結束作業.Text = "結束作業"
        Me.T4結束作業.UseVisualStyleBackColor = True
        Me.T4結束作業.Visible = False
        '
        'T4贈品修改
        '
        Me.T4贈品修改.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4贈品修改.ForeColor = System.Drawing.Color.Blue
        Me.T4贈品修改.Location = New System.Drawing.Point(132, 525)
        Me.T4贈品修改.Name = "T4贈品修改"
        Me.T4贈品修改.Size = New System.Drawing.Size(120, 47)
        Me.T4贈品修改.TabIndex = 190
        Me.T4贈品修改.Text = "贈品"
        Me.T4贈品修改.UseVisualStyleBackColor = True
        Me.T4贈品修改.Visible = False
        '
        'T4銷售修改
        '
        Me.T4銷售修改.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4銷售修改.ForeColor = System.Drawing.Color.Blue
        Me.T4銷售修改.Location = New System.Drawing.Point(6, 525)
        Me.T4銷售修改.Name = "T4銷售修改"
        Me.T4銷售修改.Size = New System.Drawing.Size(120, 47)
        Me.T4銷售修改.TabIndex = 189
        Me.T4銷售修改.Text = "銷售"
        Me.T4銷售修改.UseVisualStyleBackColor = True
        Me.T4銷售修改.Visible = False
        '
        'T4變更銷售
        '
        Me.T4變更銷售.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4變更銷售.ForeColor = System.Drawing.Color.Blue
        Me.T4變更銷售.Location = New System.Drawing.Point(384, 472)
        Me.T4變更銷售.Name = "T4變更銷售"
        Me.T4變更銷售.Size = New System.Drawing.Size(120, 47)
        Me.T4變更銷售.TabIndex = 188
        Me.T4變更銷售.Text = "變更銷售別"
        Me.T4變更銷售.UseVisualStyleBackColor = True
        '
        'T4回主畫面
        '
        Me.T4回主畫面.Font = New System.Drawing.Font("新細明體", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4回主畫面.ForeColor = System.Drawing.Color.Blue
        Me.T4回主畫面.Location = New System.Drawing.Point(797, 559)
        Me.T4回主畫面.Name = "T4回主畫面"
        Me.T4回主畫面.Size = New System.Drawing.Size(120, 47)
        Me.T4回主畫面.TabIndex = 187
        Me.T4回主畫面.Text = "回主畫面"
        Me.T4回主畫面.UseVisualStyleBackColor = True
        '
        'T4重新比對
        '
        Me.T4重新比對.Font = New System.Drawing.Font("新細明體", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4重新比對.ForeColor = System.Drawing.Color.Black
        Me.T4重新比對.Location = New System.Drawing.Point(671, 559)
        Me.T4重新比對.Name = "T4重新比對"
        Me.T4重新比對.Size = New System.Drawing.Size(120, 47)
        Me.T4重新比對.TabIndex = 186
        Me.T4重新比對.Text = "重新比對"
        Me.T4重新比對.UseVisualStyleBackColor = True
        Me.T4重新比對.Visible = False
        '
        'T4列出全部
        '
        Me.T4列出全部.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4列出全部.ForeColor = System.Drawing.Color.Blue
        Me.T4列出全部.Location = New System.Drawing.Point(797, 472)
        Me.T4列出全部.Name = "T4列出全部"
        Me.T4列出全部.Size = New System.Drawing.Size(120, 47)
        Me.T4列出全部.TabIndex = 185
        Me.T4列出全部.Text = "列出全部"
        Me.T4列出全部.UseVisualStyleBackColor = True
        '
        'T4非單品項
        '
        Me.T4非單品項.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4非單品項.ForeColor = System.Drawing.Color.Blue
        Me.T4非單品項.Location = New System.Drawing.Point(258, 472)
        Me.T4非單品項.Name = "T4非單品項"
        Me.T4非單品項.Size = New System.Drawing.Size(120, 47)
        Me.T4非單品項.TabIndex = 184
        Me.T4非單品項.Text = "非單據品項"
        Me.T4非單品項.UseVisualStyleBackColor = True
        '
        'T4列出已出
        '
        Me.T4列出已出.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4列出已出.ForeColor = System.Drawing.Color.Blue
        Me.T4列出已出.Location = New System.Drawing.Point(132, 472)
        Me.T4列出已出.Name = "T4列出已出"
        Me.T4列出已出.Size = New System.Drawing.Size(120, 47)
        Me.T4列出已出.TabIndex = 183
        Me.T4列出已出.Text = "列出已出庫"
        Me.T4列出已出.UseVisualStyleBackColor = True
        '
        'T4列出重覆
        '
        Me.T4列出重覆.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4列出重覆.ForeColor = System.Drawing.Color.Blue
        Me.T4列出重覆.Location = New System.Drawing.Point(6, 472)
        Me.T4列出重覆.Name = "T4列出重覆"
        Me.T4列出重覆.Size = New System.Drawing.Size(120, 47)
        Me.T4列出重覆.TabIndex = 182
        Me.T4列出重覆.Text = "列出重覆"
        Me.T4列出重覆.UseVisualStyleBackColor = True
        '
        'T4移除條碼
        '
        Me.T4移除條碼.Font = New System.Drawing.Font("新細明體", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.T4移除條碼.ForeColor = System.Drawing.Color.Red
        Me.T4移除條碼.Location = New System.Drawing.Point(6, 557)
        Me.T4移除條碼.Name = "T4移除條碼"
        Me.T4移除條碼.Size = New System.Drawing.Size(120, 47)
        Me.T4移除條碼.TabIndex = 180
        Me.T4移除條碼.Text = "移除"
        Me.T4移除條碼.UseVisualStyleBackColor = True
        '
        'T4DGV1
        '
        Me.T4DGV1.AllowUserToAddRows = False
        Me.T4DGV1.AllowUserToDeleteRows = False
        Me.T4DGV1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.T4DGV1.Location = New System.Drawing.Point(5, 60)
        Me.T4DGV1.Name = "T4DGV1"
        Me.T4DGV1.ReadOnly = True
        Me.T4DGV1.RowHeadersWidth = 28
        Me.T4DGV1.RowTemplate.Height = 24
        Me.T4DGV1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.T4DGV1.Size = New System.Drawing.Size(912, 406)
        Me.T4DGV1.TabIndex = 172
        '
        '草稿T4
        '
        Me.草稿T4.AutoSize = True
        Me.草稿T4.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.草稿T4.Location = New System.Drawing.Point(81, 10)
        Me.草稿T4.Name = "草稿T4"
        Me.草稿T4.Size = New System.Drawing.Size(40, 16)
        Me.草稿T4.TabIndex = 171
        Me.草稿T4.Text = "草稿"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label29.Location = New System.Drawing.Point(3, 10)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(88, 16)
        Me.Label29.TabIndex = 170
        Me.Label29.Text = "作業草稿："
        '
        '異常條碼T1
        '
        Me.異常條碼T1.BackColor = System.Drawing.Color.Silver
        Me.異常條碼T1.Location = New System.Drawing.Point(1012, 315)
        Me.異常條碼T1.Name = "異常條碼T1"
        Me.異常條碼T1.Size = New System.Drawing.Size(100, 26)
        Me.異常條碼T1.TabIndex = 140
        Me.異常條碼T1.Text = "查異常條碼"
        Me.異常條碼T1.UseVisualStyleBackColor = False
        Me.異常條碼T1.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(922, 35)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 96)
        Me.Label4.TabIndex = 142
        Me.Label4.Text = "│" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "│" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "│" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "│" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "│" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "│"
        Me.Label4.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.Location = New System.Drawing.Point(10, 606)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(184, 16)
        Me.Label5.TabIndex = 142
        Me.Label5.Text = "______________________"
        Me.Label5.Visible = False
        '
        'PrintDialog
        '
        Me.PrintDialog.UseEXDialog = True
        '
        'La差異
        '
        Me.La差異.AutoSize = True
        Me.La差異.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.La差異.ForeColor = System.Drawing.Color.Red
        Me.La差異.Location = New System.Drawing.Point(598, 10)
        Me.La差異.Name = "La差異"
        Me.La差異.Size = New System.Drawing.Size(59, 16)
        Me.La差異.TabIndex = 188
        Me.La差異.Text = "有差異"
        Me.La差異.Visible = False
        '
        '出庫作業V001
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1184, 671)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.異常條碼T1)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "出庫作業V001"
        Me.Text = "出庫作業"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.T1參數1.ResumeLayout(False)
        Me.T1參數1.PerformLayout()
        CType(Me.T1DGV4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.T1DGV3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.T1DGV2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.T1DGV1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.參數2.ResumeLayout(False)
        Me.參數2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.T2DGV3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.T2DGV1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.T2DGV2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.T4修改品項.ResumeLayout(False)
        Me.T4修改品項.PerformLayout()
        CType(Me.T4DGV1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents 作業選項T1 As System.Windows.Forms.ComboBox
    Friend WithEvents 查詢單據T1 As System.Windows.Forms.Button
    Friend WithEvents 作業T1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents T1DGV1 As System.Windows.Forms.DataGridView
    Friend WithEvents 草稿T1 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents T1DGV2 As System.Windows.Forms.DataGridView
    Friend WithEvents 草稿比對T1 As System.Windows.Forms.Button
    Friend WithEvents T1DGV3 As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents 異常條碼T1 As System.Windows.Forms.Button
    Friend WithEvents 出庫T3 As System.Windows.Forms.Label
    Friend WithEvents 未入T3 As System.Windows.Forms.Label
    Friend WithEvents 重覆T3 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents 發貨作業T2 As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents 草稿T2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents 製單T2 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents 日期T2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents 日記T2 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents T2DGV1 As System.Windows.Forms.DataGridView
    Friend WithEvents 代碼T2 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents 放棄作業T2 As System.Windows.Forms.Button
    Friend WithEvents 單據條碼T1 As System.Windows.Forms.Button
    Friend WithEvents T2DGV2 As System.Windows.Forms.DataGridView
    Friend WithEvents T2DGV3 As System.Windows.Forms.DataGridView
    Friend WithEvents T2執行時間 As System.Windows.Forms.Label
    Friend WithEvents 備註T2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents 說明T2 As System.Windows.Forms.TextBox
    Friend WithEvents 查看異常T2 As System.Windows.Forms.Button
    Friend WithEvents 提單T2 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents 客戶T2 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents 客編T2 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents 簽回T2 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents 司機T2 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents 司機T1 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents 運費T2 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents 契養T2 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents 司機T3 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents 本收T2 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents 本空T2 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents 前空T2 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents 空籃T2 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents 附件T2 As System.Windows.Forms.Label
    Friend WithEvents 草稿T4 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents T4DGV1 As System.Windows.Forms.DataGridView
    Friend WithEvents 已出T2 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents 未入T2 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents 數量T2 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents 品項T2 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents 重覆T2 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents T4移除條碼 As System.Windows.Forms.Button
    Friend WithEvents T4列出重覆 As System.Windows.Forms.Button
    Friend WithEvents T4非單品項 As System.Windows.Forms.Button
    Friend WithEvents T4列出已出 As System.Windows.Forms.Button
    Friend WithEvents T4列出全部 As System.Windows.Forms.Button
    Friend WithEvents T4回主畫面 As System.Windows.Forms.Button
    Friend WithEvents T4重新比對 As System.Windows.Forms.Button
    Friend WithEvents 價格T2 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents 管理T2 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents 驗收數量T2 As System.Windows.Forms.Button
    Friend WithEvents 驗收數量L2 As System.Windows.Forms.Label
    Friend WithEvents 待轉入區T1 As System.Windows.Forms.Button
    Friend WithEvents 查看明細T1 As System.Windows.Forms.Button
    Friend WithEvents 列印單號T1 As System.Windows.Forms.Button
    Friend WithEvents T4變更銷售 As System.Windows.Forms.Button
    Friend WithEvents T4結束作業 As System.Windows.Forms.Button
    Friend WithEvents T4贈品修改 As System.Windows.Forms.Button
    Friend WithEvents T4銷售修改 As System.Windows.Forms.Button
    Friend WithEvents T4修改品項 As System.Windows.Forms.GroupBox
    Friend WithEvents T4品名 As System.Windows.Forms.Label
    Friend WithEvents T4銷售 As System.Windows.Forms.Label
    Friend WithEvents T4存編 As System.Windows.Forms.Label
    Friend WithEvents T4條碼 As System.Windows.Forms.Label
    Friend WithEvents T4ID As System.Windows.Forms.Label
    Friend WithEvents T4作業 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents 條碼明細T1 As System.Windows.Forms.Button
    Friend WithEvents 轉出檔案T2 As System.Windows.Forms.Button
    Friend WithEvents 移除草稿T1 As System.Windows.Forms.Label
    Friend WithEvents 移除作業T1 As System.Windows.Forms.Label
    Friend WithEvents 單據移除T1 As System.Windows.Forms.Button
    Friend WithEvents PrintDialog As System.Windows.Forms.PrintDialog
    Friend WithEvents T1入出 As System.Windows.Forms.Label
    Friend WithEvents 單據更換T1 As System.Windows.Forms.Button
    Friend WithEvents 顯示項目T1 As System.Windows.Forms.Button
    Friend WithEvents T1DGV4 As System.Windows.Forms.DataGridView
    Friend WithEvents 預設庫位YN As System.Windows.Forms.CheckBox
    Friend WithEvents TB預設庫位 As System.Windows.Forms.TextBox
    Friend WithEvents 參數2 As System.Windows.Forms.GroupBox
    Friend WithEvents T1參數1 As System.Windows.Forms.GroupBox
    Friend WithEvents T1CB鎖定 As System.Windows.Forms.CheckBox
    Friend WithEvents T1TB鎖定庫位 As System.Windows.Forms.TextBox
    Friend WithEvents 強制出庫 As System.Windows.Forms.CheckBox
    Friend WithEvents T3 As System.Windows.Forms.TextBox
    Friend WithEvents T2 As System.Windows.Forms.TextBox
    Friend WithEvents T1 As System.Windows.Forms.TextBox
    Friend WithEvents 申請作業T2 As System.Windows.Forms.Button
    Friend WithEvents La2申請 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents 備註T2倉 As System.Windows.Forms.Label
    Friend WithEvents La差異 As System.Windows.Forms.Label
End Class
